// Записать в переменную случайное целое число в диапазоне [0; 100]. Используйте объект Math.

const result = Math.floor(Math.random() * 101);

console.log(result);
